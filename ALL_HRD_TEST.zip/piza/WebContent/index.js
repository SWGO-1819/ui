
/*window.onload = function () {
	var select=document.getElementById('pizza');
	var submit = document.getElementById("sectionbtn");
	submit.onclick = function () {
		for(var i = 0;i<4;i++){
			if (document.getElementsByTagName('input')[i].value == '') {
				alert('입력하지 않은 코드가 있습니다.')
				document.getElementsByTagName('input')[i].focus();
				return false;
			}
			else if(i==2&&select.options[select.selectedIndex].text == '피자선택') {
				alert('피자코드를 선택해주세요');
				select.focus();
				return false;
			}
		}
	}
};*/
window.onload = function () {
	var select=document.getElementById('pizza');
	var submit = document.getElementById("sectionbtn");
	var form = document.getElementById("frm");
	submit.onclick = function () {
		for(var i = 0;i<5;i++){
			if (form[i].value.replace(" ","")=="") {
				console.log("i:"+i);
				if (i==0) {
					alert('전표번호가 없습니다.')
				}
				else if (i==1) {
					alert('지점코드가 없습니다.')
				}
				else if (i==2) {
					alert('판매일자가 없습니다.')
				}
				else if (i==3) {
					alert('피자코드가 없습니다.')
				}
				else if(i==4){
					alert('지점코드가 없습니다.')
				}
				form[i].focus();
				return false;
			}
		}
		
		
	}
};