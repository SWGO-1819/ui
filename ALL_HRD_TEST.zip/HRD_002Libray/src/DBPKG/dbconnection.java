package DBPKG;
import java.sql.*;
public class dbconnection {
	public static Connection getConnetion() throws Exception{
		Connection conn= null;
		String url="jdbc:oracle:thin:@localhost:1521/xe";
		String user="system";
		String pw="asd123";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn=DriverManager.getConnection(url,user,pw);
		return conn;
	}
	public static ResultSet sqlPut(String sql,String type) throws Exception{
		Connection conn=null;
		ResultSet rs=null;
		PreparedStatement ptst = null;

		System.out.println(sql);
		if(type.equals("select")){
			conn=getConnetion();
			ptst=conn.prepareStatement(sql);
			rs=ptst.executeQuery();
			
		}
		else if(type.equals("update")||type.equals("insert")){
			conn=getConnetion();
			ptst=conn.prepareStatement(sql);
			int chk = ptst.executeUpdate();
			
			System.out.println("chk : "+chk);//0으로 찍히면 실행이 안되는것
			
			//ptst.close();
		}
		return rs;
	}
}
