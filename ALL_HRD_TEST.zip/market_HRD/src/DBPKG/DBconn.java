package DBPKG;

import java.sql.*;

public class DBconn {
	public static Connection getcon() throws Exception{
		Class.forName("oracle.driver.OracleDriver");
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","asd123");
		return conn;
	}
	public static ResultSet getsql(String sql) throws Exception{
		Connection conn=getcon();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		return rs;
	}
}
