/**
 * 
 */

window.onload = function(){
	var form = document.getElementById("form");
	var submit = document.getElementById("subclick");
	submit.onclick = function(){
		for(i=0;i<5;i++){
			if(form[i].value==""){
				if(i==0){
					alert("매출전표번호가 없습니다");
				}
				else if(i==1){
					alert("지점코드가 없습니다");
				}
				else if(i==2){
					alert("판매일자가 없습니다");
				}
				else if(i==3){
					alert("피자코드가 없습니다");
				}
				else if(i==4){
					alert("판매수량이 없습니다");
				}
				form[i].focus();
				return false;
			}
		}
	}
}
